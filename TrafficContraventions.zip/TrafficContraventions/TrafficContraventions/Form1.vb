﻿Public Class Form1
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Application.Exit()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        PictureBox1.Hide()
        PictureBox2.Hide()
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.Hide()
        PictureBox2.Hide()
    End Sub

    Private Sub btncheck_Click(sender As Object, e As EventArgs) Handles btncheck.Click

        Dim speed As Integer
        Dim lenght As Integer
        Dim time As Integer
        time = Convert.ToInt32(TextBox4.Text)
        lenght = Convert.ToInt32(TextBox2.Text)
        speed = lenght / time

        If speed >= 100 Then
            PictureBox1.Show()
            ListBox2.Text = TextBox1.Text
            ListBox2.Items.Add(TextBox5.Text)
            ListBox2.Items.Add(TextBox1.Text)
            ListBox2.Items.Add(speed)
            ListBox2.Show()
            ListBox2.Items.Add(" There is Trafic contravention For you ")
            ListBox1.Hide()

        End If
        If speed < 100 Then

            PictureBox2.Show()
            ListBox1.Text = TextBox1.Text
            ListBox1.Items.Add(TextBox5.Text)
            ListBox1.Items.Add(TextBox1.Text)
            ListBox1.Items.Add(speed)
            ListBox1.Items.Add("There is No Trafic contravention")
            ListBox1.Show()

        End If












    End Sub
End Class
